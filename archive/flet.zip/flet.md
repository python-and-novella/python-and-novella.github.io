# Flet的中文入门教程

## 0 前言

Flet是一个基于Flutter框架的GUI框架，就像基于Qt框架的PySide一样。但与PySide不同的是，Flet可以使用Python语言构建桌面端、Web端、移动端程序。而且Flet的思维偏向Web，如果有Web开发基础，使用Flet开发程序简直如鱼得水。当然，受限于官方教程不够系统直观且无中文，中文开发者想要入门有点费劲，因此，笔者将在梳理了官方教程和Flet的使用技巧之后，用中文重新构建入门教程。

需要提前说明的是，虽然Flet支持桌面端、Web端、移动端，但受限于框架目前还在开发阶段，且相关依赖需要良好的网络才能确保运行、构建正常，因此，本教程只介绍桌面端的运行情况，不提供部署和其他平台的运行情况。当然，Flet本身是一套代码多端运行，如果学完本教程之后，读者想要尝试其他平台，只需修改运行配置中的视图参数即可。

## 1 环境准备

和其他框架的第一步一样，本教程依然是从搭建开发环境开始。不过，开发工具的安装和Python解释器的准备太过基础，这里不再赘述，姑且认为读者已经做好了准备，且有相关基础。若是需要这部分内容，可以查阅网络资料和其他教程。

### 1.1 uv的简短教程（同时也是基础环境的准备过程）

不同于其他框架的教程，本教程将使用一个新的环境管理工具——uv（ https://docs.astral.sh/uv/#uv ），管理开发环境。

pdm已经够快够简单了，为什么还要用uv？

也许下面的速度对比图能解决这个疑问：

![uv_1](flet.assets/uv_1.png)

可以看到，尽管pdm比pip快将近60%，但uv的速度还是瞬间完成。

了解了uv的优点，接下来开始学习使用uv的常用操作（完整的操作可以学习官网文档 https://docs.astral.sh/uv/#uv ，这里仅学习初始化、管理开发环境的必要操作）。

#### 1.1.1 初始化项目

在想创建项目目录的地方，使用`uv init flet_uv_app -p 3.12`创建并初始化项目。

命令中，`init`后接着的，是想要创建的项目文件夹的名字，没有这个文件夹的话，uv会自动创建。如果想要在当前文件夹创建项目，直接使用`uv init -p 3.12`即可。

命令中，`-p`选项表示指定Python版本，如果不使用这个选项，uv会自动使用系统中可用Python的最新版本。

此命令会创建如下文件：

```shell
flet_uv_app
├─.git
├─.gitignore
├─.python-version
├─main.py
├─pyproject.toml
└─README.md
```

`.git`是文件夹，表明该项目初始化了一个git仓库。

`.gitignore`是文件，git仓库的忽略文件。

`.python-version`是文件，uv识别项目使用哪个Python版本的配置文件，可以在当前目录下使用`uv python pin 3.12`命令来生成次文件。

`main.py`是文件，uv自动创建的源代码文件。

`pyproject.toml`是文件，uv自动创建的项目配置文件，后面使用uv管理项目依赖的时候，此文件中相关内容会被修改。

`README.md`是文件，uv自动创建的项目描述文档，用于编写项目介绍、基本使用文档等非源代码内容。

初始化命令的其他选项可以使用`uv init --help`查看：

```shell
Create a new project

Usage: uv.exe init [OPTIONS] [PATH]

Arguments:
  [PATH]  The path to use for the project/script

Options:
  --name <NAME>                    The name of the project
  --bare                           Only create a `pyproject.toml`
  --package                        Set up the project to be built as a Python package
  --no-package                     Do not set up the project to be built as a Python package
  --app                            Create a project for an application
  --lib                            Create a project for a library
  --script                         Create a script
  --description <DESCRIPTION>      Set the project description
  --no-description                 Disable the description for the project
  --vcs <VCS>                      Initialize a version control system for the project [possible values: git, none]
  --build-backend <BUILD_BACKEND>  Initialize a build-backend of choice for the project [possible values: hatch, flit, pdm, poetry, setuptools, maturin, scikit]
  --no-readme                      Do not create a `README.md` file
  --author-from <AUTHOR_FROM>      Fill in the `authors` field in the `pyproject.toml` [possible values: auto, git, none]
  --no-pin-python                  Do not create a `.python-version` file for the project
  --no-workspace                   Avoid discovering a workspace and create a standalone project

Python options:
  -p, --python <PYTHON>      The Python interpreter to use to determine the minimum supported Python version. [env: UV_PYTHON=]
      --managed-python       Require use of uv-managed Python versions [env: UV_MANAGED_PYTHON=]
      --no-managed-python    Disable use of uv-managed Python versions [env: UV_NO_MANAGED_PYTHON=]
      --no-python-downloads  Disable automatic downloads of Python. [env: "UV_PYTHON_DOWNLOADS=never"]

Cache options:
  -n, --no-cache               Avoid reading from or writing to the cache, instead using a temporary directory for the duration of the operation [env: UV_NO_CACHE=]
      --cache-dir <CACHE_DIR>  Path to the cache directory [env: UV_CACHE_DIR=]

Global options:
  -q, --quiet...                                   Use quiet output
  -v, --verbose...                                 Use verbose output
      --color <COLOR_CHOICE>                       Control the use of color in output [possible values: auto, always, never]
      --native-tls                                 Whether to load TLS certificates from the platform's native certificate store [env: UV_NATIVE_TLS=]
      --offline                                    Disable network access [env: UV_OFFLINE=]
      --allow-insecure-host <ALLOW_INSECURE_HOST>  Allow insecure connections to a host [env: UV_INSECURE_HOST=]
      --no-progress                                Hide all progress outputs [env: UV_NO_PROGRESS=]
      --directory <DIRECTORY>                      Change to the given directory prior to running the command
      --project <PROJECT>                          Run the command within the given project directory [env: UV_PROJECT=]
      --config-file <CONFIG_FILE>                  The path to a `uv.toml` file to use for configuration [env: UV_CONFIG_FILE=]
      --no-config                                  Avoid discovering configuration files (`pyproject.toml`, `uv.toml`) [env: UV_NO_CONFIG=]
  -h, --help                                       Display the concise help for this command
```

除了默认的快速创建项目的命令，还有其他可能需要用到、改变的选项：

-   `--name`选项，指定项目的名称。
-   `--bare`选项，只创建`pyproject.toml`文件。

#### 1.1.2 初始化环境

初始化了项目之后，就要开始创建虚拟环境。但在创建虚拟环境、添加包之前，最好配置一下pypi的镜像地址。不同于pip可以使用命令全局配置，uv目前只能通过修改配置文件来配置镜像。

在 `~/.config/uv/uv.toml` 或者 `/etc/uv/uv.toml` 中填写下面的内容：

```toml
[[index]]
url = "https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple/"
default = true
```

对于Windows系统来说，这个文件是`%APPDATA%\uv\uv.toml`（需要手动创建）。

对于不想全局修改，只影响项目的话，添加至`pyproject.toml`文件即可。

使用`uv add flet[all]`和`uv remove flet[all]`添加删除包，会同时创建虚拟环境。

如果只想创建虚拟环境，而不添加任何包，可以使用`uv venv`。

如果`pyproject.toml`文件已经配置好依赖，无需添加包，则可以使用`uv sync`命令，让虚拟环境同步依赖情况（没有虚拟环境的话会自动创建虚拟环境）。

#### 1.1.3 包（依赖）的版本管理

上面的操作都是自动使用最新版本的包，对于想要使用指定版本（非最新）的包，需要提前在`pyproject.toml`文件指定依赖版本，再使用`uv sync`命令同步虚拟环境。如果依赖版本变动，则需要使用`uv sync`命令同步一次虚拟环境才能使用正确的版本。

不过需要注意的是，如果依赖有新版本且升级不影响兼容性，`uv sync`命令不会自动升级依赖版本。因为项目目录下会有uv自动生成的锁定文件——`uv.lock`（使用`uv lock`也能单独生成），该文件规定了虚拟环境使用的依赖版本和对应的文件信息，确保虚拟环境的版本依赖是正确的。

当然，删除此文件，修改依赖的版本号，再使用`uv lock`单独生成此文件，再使用`uv sync`命令（或者直接使用此命令）同步虚拟环境依赖版本，是一个有效但不简洁的操作。这里更推荐使用`uv lock -U`（同`uv lock --upgrade`）升级依赖版本，然后使用`uv sync`命令同步虚拟环境依赖版本。抑或使用`uv sync -U`（同`uv sync --upgrade`）一步到位。

不同于pip查看依赖的不直观，uv提供了`uv tree`，可以用树形图展示项目的依赖情况：

![uv_3](flet.assets/uv_3.png)

#### 1.1.4 运行

到此，环境已经准备好，可以开发、运行Flet程序了。

当然，为了鼓舞读者的热情，先运行一个现成的示例代码试试水。将下面的内容覆盖项目文件夹中`main.py`的原本内容：

```python3
import flet as ft

def main(page: ft.Page):
    page.title = 'Hello World'
    page.window.center()
    page.window.width,page.window.height = 800,400
    page.add(
        button := ft.Button('close app'),
    )
    button.on_click = lambda e:page.window.close()

ft.app(target=main)
```

然后，在`main.py`同级目录下打开命令行，使用`uv run python main.py`运行。即可看到运行结果：

![uv_2](flet.assets/uv_2.png)

这个命令中，`uv run python main.py`表示使用虚拟环境的Python运行`main.py`，和在开发工具中直接运行一样。

对于Flet程序，除了直接使用Python解释器运行，Flet还提供了一个`flet`命令，可以直接运行`flet run`，会自动运行`main.py`（只能是该名字的源代码）。

但是，直接运行`flet run`，使用的是系统全局的`flet`命令，这里的Flet是安装到虚拟环境中，因此，使用`uv run flet run`才是正确的。

#### 1.1.5 总结

简短教程介绍的命令可以查阅下表，快速使用：

| 命令                                 | 作用                                                         |
| ------------------------------------ | ------------------------------------------------------------ |
| `uv init flet_uv_app -p 3.12`        | 创建`flet_uv_app`文件夹，并在文件夹中初始化项目，指定Python版本为3.12 |
| `uv init -p 3.12`                    | 在当前文件夹中初始化项目，指定Python版本为3.12               |
| `uv python pin 3.12`                 | 在当前文件夹创建指定Python版本为3.12的配置文件               |
| `uv init --help`                     | 查看`init`命令的帮助文档                                     |
| `uv add flet[all]`                   | 添加包，并创建虚拟环境（如果不存在虚拟环境的话）             |
| `uv remove flet[all]`                | 添加包，并创建虚拟环境（如果不存在虚拟环境的话）             |
| `uv venv`                            | 在当前目录创建虚拟环境                                       |
| `uv sync`                            | 让虚拟环境同步依赖情况（没有虚拟环境的话会自动创建虚拟环境） |
| `uv sync -U`<br>`uv sync --upgrade`  | 升级锁文件中依赖的版本并同步虚拟环境的依赖版本               |
| `uv lock`                            | 创建锁文件                                                   |
| `uv lock -U`<br/>`uv lock --upgrade` | 升级锁文件中的依赖版本                                       |
| `uv tree`                            | 以树形视图形式查看依赖情况                                   |
| `uv run python main.py`              | 使用虚拟环境的Python运行`main.py`                            |
| `uv run flet run`                    | 运行虚拟环境提供的命令（系统命令也可以，但要求是全局路径中的可执行文件） |

## 2 基础知识

准备好环境之后，接下来就可以正式开始Flet的开发工作。但在学习基础之前，还需要了解一个开发调试的技巧。

前面介绍过使用`flet run`运行当前目录下的`main.py`，其实，该命令还可以指定目录名或者文件名，表示运行指定目录下的`main.py`或者指定文件。

为了方便开发调试，Flet还提供了热重载功能，可以让代码修改实时生效，只需使用`flet run -d`运行。此时，任何对`main.py`文件（或者指定文件）所在目录下的文件的修改都会导致程序无感重启，代码改动实时生效。需要注意的是，只是使用`flet run -d`运行，程序检测的是`main.py`文件（或者指定文件）所在目录，如果所在目录的其他子级目录的文件修改，则不会触发重启。此时需要添加`-r`选项，将子级目录也添加到检测范围中。

除了使用`flet run main.py`来运行程序，还可以省略`run`，直接使用`flet main.py`来运行。注意，这种省略方式仅限指定了目录（等于运行指定目录下的`main.py`）或者文件名（即使是`main.py`也要写上）的情况下使用，且支持`-d`和`-r`选项。

### 2.1 认识Flet程序

#### 2.1.1 Flet的`Hello World`

大部分编程语言、框架都是从最简单的`Hello World`程序开始，Flet也不例外：

```python3
import flet as ft

def main(page: ft.Page):
    page.add(
        ft.Button(
            text = 'Hello World',
            on_click = lambda e:page.open(
                ft.AlertDialog(
                    title='Hello',
                    content=ft.Text('Hello World')
                )
            )
        )
    )
    
ft.app(target=main)
```

![hello_world_1](flet.assets/hello_world_1.png)

#### 2.1.2 基础概念

在正式学习Flet的基础之前，需要先对图形界面有个基础的理解。

一般来说，搭建图形界面需要理解三个概念：控件、布局、交互。

##### 2.1.2.1 控件

控件是搭建图形界面的基本元素，就像是盖房子用的砖、门、窗等最小搭建单位。控件通常是图形界面框架提供、直接可用的。如果使用过程中发现基本元素不够，可以结合布局功能，用基本元素组合出新的控件。

##### 2.1.2.2 布局

布局是排布控件的方式，就像是房屋的基本框架。用砖可以铺地，也可以垒墙，对于砖而言，墙或是地，就是布局。控件是横向排列还是竖向排列，是像网格一样一一对应，还是大控件套着小控件，都是由布局控制。大部分图形程序框架提供的布局类似，除了基本的几种布局之外，部分图形程序框架还提供额外的组合布局。

##### 2.1.2.3 交互

交互是图形界面的重中之重，也是一个程序最难的部分。论难度的话，前面的控件和布局的学习只是对照文档，按图索骥，交互则需要身经百战，不断积累经验。

事件机制是目前大部分图形界面采用的交互反馈机制，也就是基于特定的事件触发，执行对应的函数。微软的winform中采用的消息机制，Qt的信号与槽，现代网页开发中的event事件监听，都可以理解为事件机制，只是对于winform和Qt而言，他们框架内的事件分别叫做消息和信号而已。

除了事件机制，美化也是交互的一部分。大部分现代图形界面框架。如Qt、WPF以及一系列基于网页开发的图形界面框架，支持CSS或者类似语法的美化功能，让图形界面变得更加美观，也让控件的动画效果更加丰富，这个极大提升了用户的使用体验。

此外，基于图形界面框架的特性，后端的处理逻辑以及数据的传递也是交互的一部分。在函数内，对于控件的控制，如何做到符合要求，毕竟有的框架、编程语言不支持没有定义或者声明函数就调用，而有的语言不支持声明函数。如果需要让控件显示的文本与另一个控件的文本一致，如何处理数据同步过程也需要技巧。

##### 2.1.2.4 Flet程序的对应

在`Hello World`示例中，使用了导入语句`import flet as ft`导入了`flet`，`flet`包含大部分控件（部分开头大写的类）、功能（全小写函数和非控件的类），可以快速使用控件创建界面。当然，布局控件也是控件，这也是大多数现代GUI框架的设计思路。所以，使用相关布局时，无需单独导入。

需要注意的是，Flet的控件是通过修改属性来修改显示的内容，但在修改了属性之后，不会立刻刷新显示，而是需要等下次触发刷新或者手动调用`update`方法主动触发刷新，才能让控件的内容变动生效。

在交互方面，Flet采用的是类似网页端的事件响应机制，'on_'开头方法或属性会响应对应的事件，开发者需要设置对应方法或属性为需要执行的操作。

##### 2.1.2.5 Flet程序的基本组成

在`Hello World`示例中，若是严格区分的话，一个Flet程序的源代码主要由两部分组成：

-   定义的`main`函数是程序的主要入口，该函数接收一个`Page`类型参数，表示程序的主页面，所有的控件和布局都是挂载在主页面（简化模型，其实还有一个视图，高阶技巧中会单独详细介绍）下：

    ```shell
    Page
     ├─ TextField
     ├─ Dropdown
     │   ├─ Option
     │   └─ Option
     └─ Row
         ├─ ElevatedButton
         └─ ElevatedButton
    ```

-   `ft.app(target=main)`使用主要入口函数，进入Flet程序的事件循环中，一旦程序退出，该函数就会自动跳出循环。如果该行代码下面还有内容的话，Python就会继续执行下去。

### 2.2 基础技巧

本节主要内容参考自 https://flet.dev/docs/getting-started/ 。

对于Flet程序来说，基础方面没有特别需要注意的地方，大部分需要学习的也就是具体控件的用法，这也是Flet框架广受欢迎的原因。

#### 2.2.1 添加控件

本节主要内容参考自 https://flet.dev/docs/getting-started/flet-controls 。

默认情况下，控件都是直接挂载到主页面（本质上也是个控件，但是主页面是最顶层的控件）下。注意，这里的说法是简化的，其实控件是挂载到页面的默认视图下，属于间接挂载。这里为了方便理解，所以省略了视图一级。在后面高阶技巧中会单独讲解视图的用法，在此之前请读者忽略掉视图的存在，有助于快速理解基础。

想要给主页面添加控件，有两种方式：

-   调用`add`方法添加。
-   设置主页面的`controls`属性（列表类型）。

调用`add`方法很简单：

```python3
import flet as ft

def main(page: ft.Page):
    page.add(
        ft.Button(
            text = 'Hello World',
            on_click = lambda e:page.open(
                ft.AlertDialog(
                    title='Hello',
                    content=ft.Text('Hello World')
                )
            )
        )
    )
    
ft.app(target=main)
```

`add`方法支持传入多个控件，可以一次性添加多个控件。

设置主页面的`controls`属性就稍微麻烦一些，因为设置属性之后，界面的显示不会立即刷新，需要主动使用`update`方法才能立即触发刷新，否则只能等其他用户操作触发被动刷新：

```python3
import flet as ft


def main(page: ft.Page):

    # 定义按钮
    button = ft.Button(text='Hello World')

    # 定义对话框
    dialog = ft.AlertDialog(
                title='Hello',
                content=ft.Text('Hello World')
            )
    
    # 定义打开对话框的函数
    def open_dialog(e):
        page.open(dialog)

    # 将按钮的点击响应函数与打开对话框的函数绑定
    button.on_click = open_dialog

    # 给页面的控件属性添加按钮
    page.controls.append(button)
    
    # 更新页面的显示
    page.update()

ft.app(target=main)
```

添加控件使用时，以下两个特别的技巧可以帮助读者更好地创建、管理控件，因此单独说一下。

第一个就是海象表达式（`:=`）。在使用`add`方法添加控件和设置属性添加控件之前，先单独分配控件的变量，再使用这两种方式添加，可以后期管理被添加的控件。但是，这样操作会让代码显得有些杂乱（尤其是对于使用`add`方法的方式）。此时，就可以在添加控件的同时，使用海象表达式，在添加控件的同时完成变量的分配：

```python3
import flet as ft

def main(page: ft.Page):
    page.add(
        button := ft.Button(
            text = 'Hello World',
            on_click = lambda e:page.open(
                ft.AlertDialog(
                    title='Hello',
                    content=ft.Text('Hello World')
                )
            )
        )
    )
    button.text = 'Hello Python'
    button.update()
    
ft.app(target=main)
```

另一个技巧就是使用lambda表达式。其实上面的示例已经体现出该技巧。想要让按钮响应操作，就要在创建按钮时给其`on_click`参数传入接收一个参数的可调用对象或者在创建完成后设置按钮的`on_click`属性。给所有要用到的可调用对象起名属实困难，这时就可以使用lambda表达式代替。

大部分控件有两种风格版本：Material 风格（控件名字无前缀'Cupertino'）和 Cupertino 风格（控件名字有前缀'Cupertino'）。其中，前者是非苹果系统默认使用的风格，后者是苹果系统使用的风格。具体可以参考 https://flet.dev/docs/getting-started/adaptive-apps 。

具体两种风格的控件，可以使用下面的示例对比：

```python3
import flet as ft


def main(page: ft.Page):

    # Material风格
    button = ft.Button(text='Material dialog')
    dialog = ft.AlertDialog(
                title=ft.Text('Hello'),
                content=ft.Text('Hello World')
            )
    def open_dialog(e):
        page.open(dialog)

    button.on_click = open_dialog
    page.controls.append(button)

    # Cupertino 风格
    button2 = ft.CupertinoButton(text='Cupertino dialog')
    dialog2 = ft.CupertinoAlertDialog(
                title=ft.Text('Hello'),
                content=ft.Text('Hello World')
            )
    def open_dialog2(e):
        page.open(dialog2)
    button2.on_click = open_dialog2
    page.controls.append(button2)
    
    # 更新页面的显示
    page.update()

ft.app(target=main)
```

![control_1](flet.assets/control_1.png)

![control_2](flet.assets/control_2.png)

需要注意的是，部分 Material  风格的控件同时也是自适应控件，也就是说，将其`adaptive`参数设置为`True`的话，当程序识别到主机为苹果系统时，将自动转换为 Cupertino 风格控件（仅限词根相同的控件）。

#### 2.2.2 异步与后台任务

本节主要内容参考自 https://flet.dev/docs/getting-started/async-apps 。

入口函数也可以是异步函数，这样就能在入口函数内使用异步操作（比如延迟一定时间执行特定操作）：

```python3
import flet as ft
import asyncio

async def main(page: ft.Page):
    page.add(
        button := ft.Button(
            text = 'Hello World',
            on_click = lambda e:page.open(
                ft.AlertDialog(
                    title='Hello',
                    content=ft.Text('Hello World')
                )
            )
        )
    )
    button.text = 'Hello Python'
    await asyncio.sleep(3)
    button.update()
    
ft.app(target=main)
```

上面的示例中，添加了`await asyncio.sleep(3)`，程序打开三秒以后才会更新界面显示。

不仅可以使用异步的入口函数，还可以使用异步的消息响应函数：

```python3
import flet as ft
import asyncio

async def main(page: ft.Page):
    async def open_dialog(e):
        await asyncio.sleep(3)
        page.open(
                ft.AlertDialog(
                    title='Hello',
                    content=ft.Text('Hello World')
                )
        )
    page.add(
        button := ft.Button(
            text = 'Hello World',
            on_click = open_dialog
        )
    )
    button.text = 'Hello Python'
    button.update()
    
ft.app(target=main)
```

![async_1](flet.assets/async_1.gif)

注意，虽然在使用异步的消息响应函数时，不强制要求使用异步的入口函数，但最好还是在异步的入口函数，避免出现无法预料的异步问题。

lambda表达式没有异步版本，但不能在lambda表达式中使用异步操作：

```python3
import flet as ft
import asyncio

async def main(page: ft.Page):
    async def open_dialog(e,title = 'Hello'):
        await asyncio.sleep(3)
        page.open(
                ft.AlertDialog(
                    title=title,
                    content=ft.Text('Hello World')
                )
        )
    page.add(
        button := ft.Button(
            text = 'Hello World',
            on_click = lambda e:open_dialog(e,'Hello') # 不能在lambda表达式中使用任何异步操作、异步函数
        )
    )
    button.text = 'Hello Python'
    button.update()
    
ft.app(target=main)
```

对于Flet程序来说，使用异步的好处就是可以避免阻塞后台操作、卡顿等问题。比如，在前面的示例中，使用了`await asyncio.sleep(3)`作为延迟特定时间的操作，如果使用`time.sleep(3)`代替，虽然示例没有什么明显问题，但是此类操作太多的话，会导致程序出现卡顿等问题：

```python3
import flet as ft
import time

def main(page: ft.Page):
    def open_dialog(e,title = 'Hello'):
        time.sleep(3)
        page.open(
                ft.AlertDialog(
                    title=title,
                    content=ft.Text('Hello World')
                )
        )
    page.add(
        button := ft.Button(
            text = 'Hello World',
            on_click = open_dialog
        )
    )
    button.text = 'Hello Python'
    button.update()
    
ft.app(target=main)
```

虽然在入口函数直接执行一两个耗时操作不会有明显影响，但依然建议将耗时操作放到后台执行。

有两种方式运行后台任务：

-   `page.run_task`方法，运行异步函数。
-   `page.run_thread`方法，运行非异步函数。

这两个方法都支持以下参数：

-   `handler`参数，可调用类型，表示要执行的操作。注意，要执行的操作需要传入位置参数时，不要用关键字方式传入此参数。
-   `*args`参数，紧接着`handler`参数的所有位置参数，都会严格按照顺序传给要执行的操作，作为要执行操作的位置参数。
-   `**kwargs`参数，最后一个位置参数之后的所有关键字参数（没有位置参数的话就是除了`handler`参数之外其余关键字参数），都会传给要执行的操作，作为要执行操作的关键字参数。

以下示例展示了两种运行后台任务的方式：

```python3
import flet as ft
import asyncio
import time
from datetime import datetime

async def main(page: ft.Page):
    page.add(
        text := ft.Text(f'{datetime.now()}'),
        text2 := ft.Text(f'{datetime.now()}')
    )
    
    async def update_time(name=None,*,end=''):
        while True:
            text.value = f'{name} is {datetime.now()} {end}'
            text.update()
            await asyncio.sleep(1)
            
    page.run_task(update_time,'Time',end='.')
    
    def update_time_sync(name=None,*,end=''):
        while True:
            text2.value = f'{name} is {datetime.now()} {end}'
            text2.update()
            time.sleep(1)
            
    page.run_thread(update_time_sync,'Time',end='.')

ft.app(target=main)
```

![async_2](flet.assets/async_2.gif)

需要注意的是，Flet 0.28.2 版本中，`page.run_thread`方法没法正常接收`**kwargs`参数。不过，该问题已经提交，可能很快就会修复，如果使用的是 0.28.2 版本或者教程发布时问题没有修复，可以使用下面的补丁代码。

在导入所有库之后添加下面的补丁代码：

```python3
# patch is here
from flet.core.page import _session_page
from typing import (
    Any,
    Callable,
)
from flet.core.types import (
    Wrapper,
)
class Page(__import__('flet').Page):
    def __context_wrapper(self, handler: Callable[..., Any]) -> Wrapper:
        def wrapper(*args,**kwargs):
            _session_page.set(self)
            handler(*args,**kwargs)
        return wrapper
# patch is over
```

然后，在入口函数的第一行添加下面的运行时补丁：

```python3
# runtime patch code is here
    page = Page(
        page.connection,
        page.session_id,
        executor=page.executor,
        loop=page.loop
    )
# runtime patch code is over
```

完整代码如下：

```python3
import flet as ft
import asyncio
import time
from datetime import datetime

# patch is here
from flet.core.page import _session_page
from typing import (
    Any,
    Callable,
)
from flet.core.types import (
    Wrapper,
)
class Page(__import__('flet').Page):
    def __context_wrapper(self, handler: Callable[..., Any]) -> Wrapper:
        def wrapper(*args,**kwargs):
            _session_page.set(self)
            handler(*args,**kwargs)
        return wrapper
# patch is over

async def main(page: ft.Page):

    # runtime patch code is here
    page = Page(
        page.connection,
        page.session_id,
        executor=page.executor,
        loop=page.loop
    )
    # runtime patch code is over

    page.add(
        text := ft.Text(f'{datetime.now()}'),
        text2 := ft.Text(f'{datetime.now()}')
    )
    async def update_time(name=None,*,end=''):
        while True:
            text.value = f'{name} is {datetime.now()} {end}'
            text.update()
            await asyncio.sleep(1)
            
    page.run_task(update_time,'Time',end='.')
    
    def update_time_sync(name=None,*,end=''):
        while True:
            text2.value = f'{name} is {datetime.now()} {end}'
            text2.update()
            time.sleep(1)
            
    page.run_thread(update_time_sync,'Time',end='.')

    
ft.app(target=main)
```

#### 2.2.3 颜色与主题

##### 2.2.3.1 颜色

本节主要内容参考自 https://flet.dev/docs/reference/colors 。

在Flet中，需要设置颜色的地方（控件的前景色和背景色等），支持以下几种颜色的表达方式：

-   颜色名字（大小写均可），比如`'red'`。支持的名字参考`flet.Colors`和`flet.CupertinoColors`的源码。注意，`flet.CupertinoColors`表示的是Cupertino风格使用的颜色，部分颜色存在缺失（该风格不使用）。
-   颜色枚举对象成员，比如`flet.Colors.red`。这种表达方式比较推荐，不像颜色名字需要记忆，此方法可以借助开发工具的自动提示，可以简单搜索所需的颜色。
-   量化表达的RGB颜色，比如`'#FF0000'`和`'0xFF0000'`。前缀有'#'、'0x'两种，后接六位十六进制数字（大小写均可）表达的RGB颜色，格式为`RRGGBB`。
-   颜色对象（不推荐），比如`flet.Colors('red')`。给颜色枚举类传入支持的颜色名字（要求小写且必须是类内有的名字），就和使用颜色枚举对象成员一样。

以下为示例：

```python3
import flet as ft

def main(page: ft.Page):
    page.add(
        *[ft.Button(text=f'{color} Button', bgcolor=color)
            for color in [
                'red',
                'RED',
                ft.Colors.RED,
                '#FF0000',
                '0xFF0000',
                ft.Colors(ft.Colors.RED.name.lower())
            ]
        ]
    )

ft.app(target=main)
```

![color_1](flet.assets/color_1.png)

量化表示的颜色可以自由控制颜色深度，但是用起来要求对颜色有一定理解。好在其他颜色表达方式（依据的是颜色枚举对象成员）也提供了几种预置的颜色深度表达方式，可以快速控制颜色深度：

-   直接在颜色名字后加数字，表示对应的深度，支持`50/100/200/300/400/500/600/700/800/900`，其中`500`表示与无数字后缀一样的深度，小于500的表示颜色变浅，大于500表示颜色变深。比如`'red100'`。
-   颜色名字加'accent'是另一种加深颜色的方式。加了后缀之后，该颜色会稍微变深一些，用于区分同前缀颜色，表示强调。当然，这种稍微加深一些的颜色同样支持后面再加数字，控制不同级别的深度，不过仅支持`100/200/400/700`。比如`'redaccent100'`。
-   颜色枚举对象成员同样支持上面两种深度控制方式，但成员名字需要使用下划线间隔后缀，比如`flet.Colors.RED_ACCENT_100`。

以下为示例：

```python3
import flet as ft

def main(page: ft.Page):
    page.add(
        *[ft.Button(text=f'{color} Button', bgcolor=color)
            for color in [
                'red100',
                ft.Colors.RED_100,
                'redaccent100',
                ft.Colors.RED_ACCENT_100
            ]
        ]
    )


ft.app(target=main)
```

![color_2](flet.assets/color_2.png)

颜色深度看上去像是控制了颜色的透明度，但与透明度不一样，透明度有单独的设置方式。给颜色设置透明度的话，有以下几种方式：

-   在表示颜色的字符串中，使用英文逗号分隔，后接小数表示的透明度，比如`'red100,0.5'`。
-   使用包含透明度的量化表达，格式与前面量化表达的RGB颜色类似，只不过这里的格式是格式为`AARRGGBB`，前两位是十六进制表示的透明度，`00`为完全透明，`ff`为完全不透明，比如`'#80ffcdd2'`表示50%的透明度。
-   `flet.Colors`类和`flet.CupertinoColors`类的静态方法`with_opacity`接收一个表示透明度的参数`opacity`，但使用此方法时，需要同时给第二个表示颜色的参数`color`传入颜色，比如`flet.Colors.with_opacity(0.5,'red100')`。

示例如下：

```python3
import flet as ft


def main(page: ft.Page):
    page.add(
        *[ft.Button(text=f'{color} Button', bgcolor=color)
            for color in [
                'red100,0.5',
                '#80ffcdd2',
                ft.Colors.with_opacity(0.5,'red100')
            ]
        ]
    )

ft.app(target=main)
```

![color_3](flet.assets/color_3.png)

##### 2.2.3.2 主题

本节主要内容参考自 https://flet.dev/docs/cookbook/theming 。

如果每个控件都不使用默认的颜色的话，每个控件都设置一次颜色总归是麻烦。因此，使用主题功能设置默认的颜色是最方便的。

以下为示例：

```python3
import flet as ft

def main(page: ft.Page):
    page.theme = ft.Theme(color_scheme_seed=ft.Colors.GREEN)
    page.dark_theme = ft.Theme(color_scheme_seed=ft.Colors.RED)
    page.add(
        ft.Button('Button')
    )

ft.app(target=main)
```

![theme_1](flet.assets/theme_1.png)

在Flet中，主题有两种风格：明亮风格，同时也是默认的风格；黑暗风格，也可以称之为夜间模式、深色风格、深色模式。示例中的程序因为跟随系统使用了深色模式，因此只有黑暗风格的主题生效。默认情况下，Flet程序使用的主题风格跟随系统，但可以通过设置`theme_mode`参数或属性来决定使用什么主题风格。

`theme_mode`参数或属性支持以下类型的值：

-   字符串类型，仅支持`['system',light','dark']`，分别对应跟随系统、明亮风格、黑暗风格。
-   主题模式枚举对象（`flet.ThemeMode`）成员，比如`flet.ThemeMode.LIGHT`。

以下为示例：

```python3
import flet as ft

def main(page: ft.Page):
    page.theme = ft.Theme(color_scheme_seed=ft.Colors.GREEN)
    page.dark_theme = ft.Theme(color_scheme_seed=ft.Colors.RED)
    page.theme_mode = ft.ThemeMode.LIGHT # 或者 'light'
    
    page.add(
        ft.Button('Button'),
        ft.Container(
            ft.Button(text=f'Button'),
            theme=ft.Theme(color_scheme_seed=ft.Colors.BLUE),
            dark_theme=ft.Theme(color_scheme_seed=ft.Colors.YELLOW),
            theme_mode='dark'
        )
    )

ft.app(target=main)
```

![theme_4](flet.assets/theme_4.png)

在学习如何创建主题之前，需要对上面的示例进行解惑，顺便讲一讲如何使用主题以及主题的生效范围。

可以看到，虽然设置`theme_mode`参数或属性之后，让程序的主题风格不再跟随系统，但也出现了两种风格同时存在的问题。其实，这并不是问题，而是主题的生效范围不同，导致控件优先使用的主题也存在不同。

使用主题时，生效的范围不同，使用的方法也有所不同：

-   全局生效。设置`page`的`theme`属性（明亮风格的主题）、`dark_theme`属性（黑暗风格的主题），则所有显示在页面中的控件都使用设定的主题。
-   局部生效。设置容器控件的`theme`参数或属性（明亮风格的主题）、`dark_theme`参数或属性（黑暗风格的主题），并同时设置容器控件的`theme_mode`参数或属性，则所有显示在容器中的控件都使用设定的主题，而非全局生效的主题。如果不设置容器控件的`theme_mode`参数或属性，则表示容器控件使用全局生效的主题。

以下为示例：

```python3
import flet as ft

def main(page: ft.Page):
    page.theme = ft.Theme(color_scheme_seed=ft.Colors.GREEN)
    page.dark_theme = ft.Theme(color_scheme_seed=ft.Colors.RED)
    
    page.add(
        ft.Button('Button'),
        ft.Container(
            ft.Button(text=f'Button'),
            theme = ft.Theme(color_scheme_seed=ft.Colors.BLUE),
            dark_theme = ft.Theme(color_scheme_seed=ft.Colors.YELLOW),
            theme_mode='dark'
        )
    )

ft.app(target=main)
```

![theme_5](flet.assets/theme_5.png)

除了主题的颜色，控件本身一般也能设置颜色，这时就存在优先级的问题。对于一般的控件来说，其使用的颜色的优先级顺序如下：控件设置的颜色 > 局部生效的主题颜色 > 全局生效的主题颜色。

不过，凡事都有例外，控件的颜色（或者主题）生效情况也是。以下是部分存在特例的控件：

-   `flet.FilledButton`控件没有`bgcolor`参数，因为该控件的背景颜色取决于其所属的父级控件使用的主题的主要颜色。

说完使用主题之前，再来说说如何创建主题。使用`flet.Theme`类创建主题对象，即可自定义主题。

`flet.Theme`类支持以下参数（仅介绍常用的部分参数，完整介绍可以参考 https://flet.dev/docs/reference/types/theme/ ）：

-   `color_scheme_seed`参数，字符串类型或者颜色枚举对象成员，表示用于计算主题其他颜色的种子颜色。

-   `font_family`参数，字符串类型，表示主题中文字使用的字体。以下为示例：

    ```python3
    import flet as ft
    
    def main(page: ft.Page):
        page.theme = ft.Theme(
            color_scheme_seed='red',
            elevated_button_theme=ft.ElevatedButtonTheme(bgcolor='green'),
            font_family='KaiTi',
        )
        page.dark_theme = ft.Theme(color_scheme_seed='red')
        page.theme_mode = 'light'
    
        page.add(
            ft.Button('Button按钮'),
            ft.Text('Text文字'),
        )
    
    ft.app(target=main)
    ```

    ![theme_3](flet.assets/theme_3.png)

-   `use_material3`参数，布尔类型，表示控件是否使用 Material  Design 3 风格，默认为`True`。为`False`的话使用 Material  Design 2 风格。以下为对比示例：

    ```python3
    import flet as ft
    
    
    def main(page: ft.Page):
        page.theme_mode = 'light'
    
        page.add(
            ft.Container(
                ft.Button('Button按钮'),
                theme=ft.Theme(
                    use_material3=True
                ),
                theme_mode='light'
            ),
            ft.Container(
                ft.Button('Button按钮'),
                theme=ft.Theme(
                    use_material3=False
                ),
                theme_mode='light'
            )
        )
    
    
    ft.app(target=main)
    ```

    ![theme_6](flet.assets/theme_6.png)

-   `color_scheme`参数，颜色方案类型，表示主题的颜色方案。不同于`color_scheme_seed`参数是自动生成主题的颜色风格，该参数可以准确指定主题的特定颜色。比如，下面的示例中准确指定了主要色（其他相关的颜色会自动生成），与自动生成主题的颜色风格对比，得到的主题更接近想要的结果：

    ```python3
    import flet as ft
    
    
    def main(page: ft.Page):
        page.theme_mode = 'light'
    
        page.add(
            ft.Container(
                ft.Button('Button按钮'),
                theme=ft.Theme(
                    color_scheme_seed='green',
                ),
                theme_mode='light'
            ),
            ft.Container(
                ft.Button('Button按钮'),
                theme=ft.Theme(
                    color_scheme=ft.ColorScheme(primary='green'),
                ),
                theme_mode='light'
            )
        )
    
    
    ft.app(target=main)
    ```

    ![theme_7](flet.assets/theme_7.png)

对于后缀为'_theme'的参数，表示的是对应控件使用的子主题，同时设置这类参数的话，对应控件将使用对应值表示的子主题，而不是主题。比如：

```python3
import flet as ft

def main(page: ft.Page):
    page.theme = ft.Theme(
        color_scheme_seed='red',
        elevated_button_theme=ft.ElevatedButtonTheme(bgcolor='green')
    )
    page.dark_theme = ft.Theme(color_scheme_seed='red')
    page.theme_mode = 'light'

    page.add(
        ft.Button('Button按钮'),
        ft.OutlinedButton('Button按钮'),
    )

ft.app(target=main)
```

![theme_2](flet.assets/theme_2.png)

需要注意的是，部分子主题对应的控件是不可以单独使用的控件。比如：

-   `scrollbar_theme`主题对应的是`ScrollBar`控件，用在`flet.Page`、`flet.View`、`flet.Column`、`flet.Row`、`flet.ListView`、`flet.GridView`等内容可以滚动的控件中，表示显示出来的滚动条，无法单独使用。

对于后缀为'_color'的参数，表示的是部分控件内容使用的主题颜色，而非控件本身的主题颜色。比如，仅在标记文本控件显示GitHub风格的Markdown文本，且文本中包含复选框时，复选框才会使用`primary_color`参数表示的颜色：

```python3
import flet as ft

def main(page: ft.Page):
    page.theme_mode = 'light'

    page.add(
        ft.Container(
            ft.Markdown(
            '- [x] Check it!',
            extension_set=ft.MarkdownExtensionSet.GITHUB_WEB,
        ),
            theme=ft.Theme(
                color_scheme_seed='green',
                primary_color='red',
            ),
            theme_mode='light'
        ),
        ft.Container(
            ft.Button(
            '- [x] Check it!',
        ),
            theme=ft.Theme(
                color_scheme_seed='green',
                primary_color='red',
            ),
            theme_mode='light'
        ),
    )


ft.app(target=main)
```

![theme_8](flet.assets/theme_8.png)

#### 2.2.4 xx（待定）

（随时补充中……）

### 2.3 其他基础技巧

本节主要介绍那些经常使用但三言两语就能说清的基础技巧。

#### 2.3.1 定时器

Flet官方目前没有添加定时器功能，不过，单独实现一个也并非难事。

以下代码源于 https://github.com/omamkaz/flet-timer 。

下面的代码定义了`Timer`类和`debounce`装饰器，可以方便快捷地定时执行指定操作。

```python3
import threading
import typing
from functools import wraps

class Timer:
    def __init__(
        self,
        interval: float = 1,
        callback: typing.Callable = None,
        on_error: typing.Callable[[str], None] = None,
        wait_on_start: bool = True,
        *args,
        **kwargs
    ):
        self.interval = interval
        self.callback = callback
        self.on_error = on_error
        self.wait_on_start = wait_on_start
        self.active = False
        self.paused = False
        self.pause_condition = threading.Condition(threading.Lock())
        self.th = threading.Thread(target=self.tick, daemon=True)
    def set_interval(self, interval: float) -> None:
        self.interval = interval
    def set_callback(self, callback: typing.Callable) -> None:
        self.callback = callback
    def start(self):
        self.active = True
        self.paused = False
        if not self.th.is_alive():
            if self.wait_on_start:
                threading.Event().wait(self.interval)
            self.th = threading.Thread(target=self.tick, daemon=True)
            self.th.start()
    def stop(self):
        self.active = False
        self.resume()
    def pause(self):
        with self.pause_condition:
            self.paused = True
    def resume(self):
        with self.pause_condition:
            self.paused = False
            self.pause_condition.notify()
    def tick(self):
        while self.active:
            with self.pause_condition:
                while self.paused:
                    self.pause_condition.wait()
            try:
                if self.callback:
                    self.callback()
            except Exception as e:
                self.on_error(e)
            threading.Event().wait(self.interval)

class debounce:
    def __init__(self, timeout: float = 1):
        self.timeout = timeout
        self._timer = None
    def __call__(self, func: typing.Callable):
        @wraps(func)
        def decorator(*args, **kwargs):
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(self.timeout, func, args=args, kwargs=kwargs)
            self._timer.start()
        return decorator
```

`Timer`类为定时器，可以间隔指定时间循环执行指定操作。`debounce`装饰器装饰函数之后，若函数在指定的时间内重复执行，则以最后一次执行函数的时间为起点，到达指定时间之后，只有最后一次执行的函数才会响应。

需要注意的是，定义了定时器之后，需要手动调用`start`方法才算启动了定时器。

以下为完整示例：

```python3
import flet as ft
from datetime import datetime

import threading
import typing

class Timer:
    def __init__(
        self,
        interval: float = 1,
        callback: typing.Callable = None,
        on_error: typing.Callable[[str], None] = None,
        wait_on_start: bool = True,
        *args,
        **kwargs
    ):
        self.interval = interval
        self.callback = callback
        self.on_error = on_error
        self.wait_on_start = wait_on_start
        self.active = False
        self.paused = False
        self.pause_condition = threading.Condition(threading.Lock())
        self.th = threading.Thread(target=self.tick, daemon=True)
    def set_interval(self, interval: float) -> None:
        self.interval = interval
    def set_callback(self, callback: typing.Callable) -> None:
        self.callback = callback
    def start(self):
        self.active = True
        self.paused = False
        if not self.th.is_alive():
            if self.wait_on_start:
                threading.Event().wait(self.interval)
            self.th = threading.Thread(target=self.tick, daemon=True)
            self.th.start()
    def stop(self):
        self.active = False
        self.resume()
    def pause(self):
        with self.pause_condition:
            self.paused = True
    def resume(self):
        with self.pause_condition:
            self.paused = False
            self.pause_condition.notify()
    def tick(self):
        while self.active:
            with self.pause_condition:
                while self.paused:
                    self.pause_condition.wait()
            try:
                if self.callback:
                    self.callback()
            except Exception as e:
                self.on_error(e)
            threading.Event().wait(self.interval)

def main(page: ft.Page):
    page.add(
        text := ft.Text(f'{datetime.now()}')
    )

    def update_time(name=None,*,end=''):
        text.value = f'{name} is {datetime.now()} {end}'
        text.update()

    Timer(interval=1,callback=lambda :update_time('Timer',end='.')).start()

    
ft.app(target=main)
```

![timer_1](flet.assets/timer_1.gif)

#### 2.3.2 关闭窗口

Flet是一个GUI框架，在开发桌面程序中，经常会设计无边框程序。启用无边框也就意味着没有了常规的关闭按钮，无法正常关闭窗口。此时，就需要用到关闭窗口的方法：`close`方法和`destroy`方法。启用无边框和关闭窗口的方法均是`page.window`的属性、方法，具体可以参考 https://flet.dev/docs/reference/types/window/ 。

以下为启用无边框的同时，添加了关闭窗口按钮的示例：

```python3
import flet as ft

def main(page: ft.Page):
    page.window.frameless= True
    page.add(
        ft.Button(text='close window',on_click=lambda e:page.window.close()),
        ft.Button(text='destroy window',on_click=lambda e:page.window.destroy())
    )

ft.app(target=main)
```

![frameless_1](flet.assets/frameless_1.png)

#### 2.3.3 使用图标

控件中可以设置图标的参数或属性，均支持字符串或者图标枚举对象成员（完整用法参考 https://flet.dev/docs/reference/icons ），示例如下：

```python3
import flet as ft

def main(page: ft.Page):
    page.add(
        ft.Button('主页',icon='home'),
        ft.Button('主页',icon=ft.Icons.HOME),
    )

ft.app(target=main)
```

![icon_1](flet.assets/icon_1.png)

#### 2.3.4 xx（待定）

（随时补充中……）

## 3 具体控件（更新中）

本节主要内容参考自 https://flet.dev/docs/controls 。

Flet提供了大量美观的控件，接下来，根据分类情况，具体学习每个控件。

注意，不是所用控件、方法都支持在桌面平台使用，对于不支持桌面平台的部分，示例代码仅供参考，请读者在实际使用时根据报错自行修正。部分控件的示例可能涉及到后面才会学习的高阶技巧，如果遇到不好理解的代码，可以暂时搁置，待学习了高阶技巧之后再回来学习这部分内容。

相关功能的完整用法可以参考官方的API手册 https://flet.dev/docs/reference/ 。

### 3.1 布局控件

本节主要内容参考自 https://flet.dev/docs/controls/layout 。

#### 3.1.1 卡片控件

本节主要内容参考自 https://flet.dev/docs/controls/card 。

卡片控件是一个带圆角和阴影效果的面板，上面的内容则是其他控件，就好像一个卡片上显示着其他控件：

```python3
import flet as ft

def main(page: ft.Page):
    page.add(
        ft.Card(
            ft.Text(
                'Hello',
                width=100,
                height=40,
                text_align=ft.TextAlign.CENTER,
            ),
            shadow_color='white',
        )
    )

ft.app(target=main)
```

![card_1](flet.assets/card_1.png)

控件支持以下参数：

- `content`参数，控件类型（`flet.Control`），表示显示在控件里的内容。

- `margin`参数，整数类型或者浮点类型或者外边距类型（`flet.Margin`），表示控件的外边距。如果为整数类型或者浮点类型，表示控件的四个方向的外边距都为该值。如果为外边距类型，则可以指定各个方向上的外边距（依次对应左、上、右、下）：

  ```python3
  import flet as ft
  
  
  def main(page: ft.Page):
      page.add(
          ft.Container(
              content=ft.Card(
                  content=ft.Text(
                      value='Hello',
                      width=100,
                      height=40,
                      text_align=ft.TextAlign.CENTER,
                  ),
                  shadow_color='white',
                  margin=ft.Margin(
                      left=10, 
                      top=20, 
                      right=40, 
                      bottom=80
                  ),
              ),
              bgcolor='blue'
          )
      )
  
  
  ft.app(target=main)
  ```

  ![card_2](flet.assets/card_2.png)

- `elevation`参数，整数类型或者浮点类型，表示控件到阴影的高度（需要设置表示阴影颜色的参数`shadow_color`才能看到效果），默认高度为`1`。示例如下：

  ```python3
  import flet as ft
  
  
  def main(page: ft.Page):
      for value in [
          0,1,10
      ]:
          page.add(
          	ft.Card(
              	content=ft.Text(
                  	value='Hello',
                  	width=100,
                  	height=40,
                  	text_align=ft.TextAlign.CENTER,
              	),
              	shadow_color='white',
              	elevation=value
          	)
      	)
  
  ft.app(target=main)
  ```

  ![card_3](flet.assets/card_3.png)

- `color`参数，字符串类型或者颜色枚举对象成员，表示控件的背景颜色。

- `shadow_color`参数，字符串类型或者颜色枚举对象成员，表示控件的阴影颜色。

- `surface_tint_color`参数，字符串类型或者颜色枚举对象成员，表示在控件的背景颜色的基础上轻微混合的其他颜色。示例如下：

  ```python3
  import flet as ft
  
  def main(page: ft.Page):
      for value in [
          'red','green','blue'
      ]:
          page.add(
          	ft.Card(
              	content=ft.Text(
                  	value='Hello',
                  	width=100,
                  	height=40,
                  	text_align=ft.TextAlign.CENTER,
              	),
              	shadow_color='white',
              	surface_tint_color=value,
          	)
      	)
  
  ft.app(target=main)
  ```

  ![card_4](flet.assets/card_4.png)

- `shape`参数，轮廓边框类型（基类为`flet.OutlinedBorder`类），表示轮廓（或者叫边框）的形状，默认为半径12个像素的圆角矩形。该参数支持以下类型的值：

  - `flet.RoundedRectangleBorder`类型，表示圆角矩形轮廓。
  - `flet.BeveledRectangleBorder`类型，表示切角矩形轮廓。
  - `flet.ContinuousRectangleBorder`类型，表示半径连续变化的圆角矩形轮廓。
  - `flet.StadiumBorder`类型，表示跑道形轮廓。
  - `flet.CircleBorder`类型，表示圆形轮廓。

  示例如下：

  ```python3
  import flet as ft
  
  
  def main(page: ft.Page):
      for value in [
          None,
          ft.RoundedRectangleBorder(radius=12),
          ft.BeveledRectangleBorder(radius=12),
          ft.ContinuousRectangleBorder(radius=120),
          ft.StadiumBorder(),
          ft.CircleBorder(),
      ]:
          page.add(
              ft.Card(
                  content=ft.Text(
                      value='Hello',
                      width=100,
                      height=40,
                      text_align=ft.TextAlign.CENTER,
                  ),
                  shadow_color='white',
                  shape=value,
              )
          )
  
  ft.app(target=main)
  ```

  ![card_5](flet.assets/card_5.png)

- `clip_behavior`参数，裁剪行为枚举对象成员（`flet.ClipBehavior`），表示当控件显示的内容边界超过控件的边界时，如何裁剪超过边界的内容。该参数支持以下类型的值：

  - `flet.ClipBehavior.NONE`，表示不裁剪，同时也是该参数的默认值。
  - `flet.ClipBehavior.HARD_EDGE`，表示裁剪但不使用抗锯齿平滑边缘。
  - `flet.ClipBehavior.ANTI_ALIAS`，表示裁剪并使用抗锯齿平滑边缘。
  - `flet.ClipBehavior.ANTI_ALIAS_WITH_SAVE_LAYER`，表示裁剪、使用抗锯齿平滑边缘，并使用缓冲层。效果和裁剪并使用抗锯齿平滑边缘一样，但因为有缓冲层的存在，会慢一些，一般不适用。

  示例如下：

  ```python3
  import flet as ft
  
  
  def main(page: ft.Page):
      for value in [
          ft.ClipBehavior.NONE,# 同'none'
          ft.ClipBehavior.HARD_EDGE,# 同'hardEdge'
          ft.ClipBehavior.ANTI_ALIAS,# 同'antiAlias'
          ft.ClipBehavior.ANTI_ALIAS_WITH_SAVE_LAYER,# 同'antiAliasWithSaveLayer'
      ]:
          page.add(
              ft.Card(
                  content=ft.Text(
                      value='Hello',
                      width=100,
                      height=40,
                      bgcolor='red'
                  ),
                  width=40,
                  shadow_color='white',
                  clip_behavior=value,
              )
          )
  
  ft.app(target=main)
  ```

  以下为不使用抗锯齿和使用抗锯齿的对比：

  ![card_6](flet.assets/card_6.png)

- `is_semantic_container`参数，布尔类型，表示控件是否为单一的语义容器控件（只包含一个确定语义的控件），默认为`True`。为`False`的话，表示控件的内容包含多个不同的语义控件。这部分内容主要和Flutter框架相关，具体可以搜索相关资料，这里不做展开。

- `show_border_on_foreground`参数，布尔类型，表示轮廓是否绘制在前景上，反之则绘制在背景上，默认为`True`。这部分内容主要和Flutter框架相关，具体可以搜索相关资料（https://cloud.tencent.com/developer/article/1958471），这里不做展开。

- `variant`参数，卡片变种枚举对象成员（`flet.CardVariant`），表示控件的基本样式，

- 



控件支持以下属性：

- `content`属性，同`content`参数。
- `margin`属性，同`margin`参数。
- `elevation`属性，同`elevation`参数。
- `color`属性，同`color`参数。
- `shadow_color`属性，同`shadow_color`参数。
- `surface_tint_color`属性，同`surface_tint_color`参数。
- `shape`属性，同`shape`参数。
- `clip_behavior`属性，同`clip_behavior`参数。
- `is_semantic_container`属性，同`is_semantic_container`参数。
- `variant`属性，同`variant`参数。

控件支持以下方法：

- 



参数值对比模板：

```python3
import flet as ft

def main(page: ft.Page):
    for value in [
        ft.CardVariant.ELEVATED,
        ft.CardVariant.FILLED,
        ft.CardVariant.OUTLINED
    ]:
        page.add(
            ft.Card(
                content=ft.Text(
                    value='Hello',
                    width=100,
                    height=40,
                    text_align=ft.TextAlign.CENTER,
                ),
                variant=value,
            )
        )

ft.app(target=main)
```







## 4 高阶技巧与实例（更新中）

除了基础知识和具体的控件用法之外，想要让Flet程序符合需求，还需要学会一些其他技巧。当然，每个技巧都有具体、可运行的实例代码。

相关功能的完整用法可以参考官方的API手册 https://flet.dev/docs/reference/ 。

### 4.1 自定义控件

本节主要内容参考自 https://flet.dev/docs/getting-started/custom-controls 。

虽然Flet内置了不少控件，但控件的功能总有不满意的时候，这时，就可以通过继承原本的控件类来扩展控件的功能：

```python3
import flet as ft

class MyButton(ft.Button):
    def __init__(self, text, on_click = None):
        super().__init__()
        self.bgcolor = ft.Colors.ORANGE_300
        self.color = ft.Colors.GREEN_800
        self.text = text
        self.on_click = lambda e:(on_click(e) if on_click else self._click())
    def _click(self):
        import flet
        self.page.open(
            flet.AlertDialog(
                title=ft.Text('Message'),
                content=ft.Text(f'{self.text} was clicked.')
            )
        )

def main(page: ft.Page):
    page.add(MyButton('MyButton'))

ft.app(target=main)
```

![custom_control_1](flet.assets/custom_control_1.gif)

需要注意的是，继承了控件类之后，必须先在初始化方法中调用一次父类的初始化方法（`super().__init__()`），才能正常使用控件、设置控件的属性。

除了上面这种单个自定义控件，还可以通过继承容器类控件，实现包含多个控件的复合自定义控件：

```python3
import flet as ft

class EditText(ft.Row):
    def __init__(self, text, on_click = None):
        import flet as ft
        super().__init__()
        self.text_view = ft.Text(text)
        self.text_edit = ft.TextField(text,visible=False)
        self.edit_button = ft.IconButton(icon=ft.Icons.EDIT, on_click=self.edit)
        self.save_button = ft.IconButton(
            visible=False, icon=ft.Icons.SAVE, on_click=self.save
        )
        self.controls = [
            self.text_view,
            self.text_edit,
            self.edit_button,
            self.save_button,
        ]
    def edit(self, e):
        self.edit_button.visible = False
        self.save_button.visible = True
        self.text_view.visible = False
        self.text_edit.visible = True
        self.update()

    def save(self, e):
        self.edit_button.visible = True
        self.save_button.visible = False
        self.text_view.visible = True
        self.text_edit.visible = False
        self.text_view.value = self.text_edit.value
        self.update()

def main(page: ft.Page):
    page.add(EditText('Hello'))

ft.app(target=main)
```

![custom_control_2](flet.assets/custom_control_2.gif)

在自定义控件类中定义下面的生命周期方法，即可在指定的时机执行特定代码：

-   `build`方法，在控件创建并分配了`self.page`后执行。
-   `did_mount`方法，在控件被添加到页面（通常是主页面）并分配了`uid`属性后执行。执行顺序在`build`方法后。
-   `will_unmount`方法，在控件从页面（通常是主页面）中移除前执行。
-   `before_update`方法，在控件执行`update`方法前执行（控件初始化时，会在执行了`build`方法后执行一次`update`方法）。注意，不能在此方法内执行`update`方法，会导致无限循环。

以下为展示生命周期方法执行顺序的示例：

```python3
import flet as ft

class EditText(ft.Row):
    def __init__(self, text, on_click = None):
        import flet as ft
        super().__init__()
        self.text_view = ft.Text(text)
        self.text_edit = ft.TextField(text,visible=False)
        self.edit_button = ft.IconButton(icon=ft.Icons.EDIT, on_click=self.edit)
        self.save_button = ft.IconButton(
            visible=False, icon=ft.Icons.SAVE, on_click=self.save
        )
        self.controls = [
            self.text_view,
            self.text_edit,
            self.edit_button,
            self.save_button,
        ]
    def edit(self, e):
        self.edit_button.visible = False
        self.save_button.visible = True
        self.text_view.visible = False
        self.text_edit.visible = True
        self.update()

    def save(self, e):
        self.edit_button.visible = True
        self.save_button.visible = False
        self.text_view.visible = True
        self.text_edit.visible = False
        self.text_view.value = self.text_edit.value
        self.update()

    def build(self):
        print('build is called.')

    def did_mount(self):
        print('did_mount is called.')

    def will_unmount(self):
        print('will_unmount is called.')

    def before_update(self):
        print('before_update is called.')

def main(page: ft.Page):
    import time
    page.add(c1 := EditText('Hello'))
    time.sleep(1)
    page.remove(c1)

ft.app(target=main)
```

输出结果为：

```shell
build is called.
before_update is called.
did_mount is called.
will_unmount is called.
```

在自定义控件类中定义`is_isolated`方法并返回布尔值，即可表明该控件是否为隔离控件。所谓隔离控件，即控件的父级控件调用`update`方法时，不会更新控件的子级控件，最多更新控件本身。如果想要更新控件的子级控件，只能调用控件的`update`方法。看上去就好像`update`方法的传递过程在隔离控件这里中断了，因此称该控件为隔离控件。

以下为隔离控件的示例：

```python3
import flet as ft

class EditText(ft.Row):
    def __init__(self, text, on_click = None):
        import flet as ft
        super().__init__()
        self.text_view = ft.Text(text)
        self.text_edit = ft.TextField(text,visible=False)
        self.edit_button = ft.IconButton(icon=ft.Icons.EDIT, on_click=self.edit)
        self.save_button = ft.IconButton(
            visible=False, icon=ft.Icons.SAVE, on_click=self.save
        )
        self.controls = [
            self.text_view,
            self.text_edit,
            self.edit_button,
            self.save_button,
        ]
        
    def is_isolated(self) -> bool:
        return True
    
    def edit(self, e):
        self.edit_button.visible = False
        self.save_button.visible = True
        self.text_view.visible = False
        self.text_edit.visible = True
        self.update()

    def save(self, e):
        self.edit_button.visible = True
        self.save_button.visible = False
        self.text_view.visible = True
        self.text_edit.visible = False
        self.text_view.value = self.text_edit.value
        self.update()

def main(page: ft.Page):
    page.add(
        c1 := EditText('Hello'),
        c2 := EditText('Hello')
    )
    c1.controls[1].visible = True
    c2.controls[1].visible = True
    page.update()
    c2.update()

ft.app(target=main)
```

![custom_control_3](flet.assets/custom_control_3.png)

可以看到，虽然两个控件都修改了子级控件的可见性，但使用主页面的`update`方法不会显示，只有使用控件的`update`方法才能显示。

需要注意的是，如果`is_isolated`方法只是返回布尔值的话，就没办法动态修改隔离属性。此时可以将返回值改为与实例属性或者类属性：

```python3
import flet as ft

class EditText(ft.Row):
    def __init__(self, text, on_click = None):
        import flet as ft
        super().__init__()
        self.text_view = ft.Text(text)
        self.text_edit = ft.TextField(text,visible=False)
        self.edit_button = ft.IconButton(icon=ft.Icons.EDIT, on_click=self.edit)
        self.save_button = ft.IconButton(
            visible=False, icon=ft.Icons.SAVE, on_click=self.save
        )
        self.controls = [
            self.text_view,
            self.text_edit,
            self.edit_button,
            self.save_button,
        ]
        self.isolated = True
    
    def is_isolated(self) -> bool:
        return self.isolated
    
    def edit(self, e):
        self.edit_button.visible = False
        self.save_button.visible = True
        self.text_view.visible = False
        self.text_edit.visible = True
        self.update()

    def save(self, e):
        self.edit_button.visible = True
        self.save_button.visible = False
        self.text_view.visible = True
        self.text_edit.visible = False
        self.text_view.value = self.text_edit.value
        self.update()

def main(page: ft.Page):
    page.add(
        c1 := EditText('Hello'),
        c2 := EditText('Hello')
    )
    c1.controls[1].visible = True
    c2.controls[1].visible = True
    c1.isolated = False
    page.update()

ft.app(target=main)
```

![custom_control_4](flet.assets/custom_control_4.png)

### 4.2 视图与路由

本节主要内容参考自 https://flet.dev/docs/getting-started/navigation-and-routing 。

前面的教程一直是使用`page.add`来添加控件，看上去像是控件都是直接挂载在主页面下，其实，在控件和主页面之间，还存在一个一直没有刻意关注过的视图：

```shell
Page
└─ View
      ├─ Button
      └─ Button
```

`page`的`views`属性是一个包含所有视图的列表，通过访问该属性，就可以发现视图的存在：

```python3
import flet as ft

def main(page: ft.Page):
    page.add(
        ft.Button('Button1')
    )
    page.add(
        ft.Button('Button2')
    )
    page.update()

    print(page.views[0].controls)

ft.app(target=main)
```

这时，可以在终端看到以下输出内容（已经格式化）：

```python3
[
    Button(
        text='Button1', 
        style='{"padding":{},"side":{},"shape":{},"text_style":{}}'
    ), 
    Button(
        text='Button2', 
        style='{"padding":{},"side":{},"shape":{},"text_style":{}}'
    )
]
```

这就是`views`属性中第一个视图包含的控件，也正是添加给`page`的控件。因此，之前章节中添加的控件，实际上全是添加给了主页面下的默认视图。而不是主页面。当然，这不是说前面故意不讲，而是视图的用法比较复杂，除非是想实现单页面应用（SPA），没必要使用视图以及路由。只是简单构建一个图像程序的话，忽略视图的存在，反而更简单一些。

不过，存在即合理，既然有视图这个功能，那就有用武之地，接下来详细说一说视图。

正如前面所介绍的那样，视图是挂载在主页面之下，保存在`views`属性中。视图就像是一张纸，`views`属性就是一叠纸，只有在最上面的纸可见，下面的纸都会被遮住，视图就有这样特性。

视图如何使用可以参考视图控件的介绍，其实视图控件那一节已经给过示例（对于视图控件的参数、属性、方法不熟悉的话，可以回顾一下），但没有细说视图的完整用法，这里就再写一个示例：

```python3
import flet as ft

def main(page: ft.Page):
    page.views.append(
        ft.View(
            '/index',
        	[ft.Button('Button')]
        )
    )
    page.views.append(
        ft.View(
            '/index2',
        	[ft.Button('Button2')]
        )
    )
    page.update()
    
ft.app(target=main)
```

此时，只能看到最上面的视图的内容：

![navi_1](flet.assets/navi_1.png)

需要注意的是，虽然视图和主页面都有一个类似路径一样的路由参数或属性——`route`，但主页面切换路径并不会关联切换视图，因为目前视图的路由参数并非Flet框架在使用（以后说不定会变），想要让路径变化与视图关联，则需要单独设置主页面的路由切换响应函数`on_route_change`，让主页面的路由与视图的路由关联，并通过`go`方法切换路径：

```python3
import flet as ft

def main(page: ft.Page):
    # 视图信息
    views = {
        '/page1':{
            'title':'Page1',
            'button':'Go Home',
            'target':'/',
        },
        '/':{
            'title':'Home',
            'button':'Go Page1',
            'target':'/page1',
        },

    }

    def route_change(route:ft.RouteChangeEvent):
        view = views.get(route.route)
        if view:
            route.page.views.clear()
            route.page.views.append(
                ft.View(
        	        route.route,
                	[
                        ft.AppBar(title=ft.Text(view['title'])),
                        ft.Button(
                            view['button'],
                            on_click=lambda e:page.go(view['target'])
                        ),
            		]
        		)
            )
        route.page.update()

    page.on_route_change = route_change
    page.go('/')

ft.app(target=main)
```

![navi_2](flet.assets/navi_2.gif)

`go`方法可以设置主页面的`route`属性，并触发`route_change`事件。该方法支持以下参数：

-   `route`参数，字符串类型，表示将主页面的`route`属性设置为什么。
-   `skip_route_change_event`参数，布尔类型，表示是否跳过`route_change`事件的触发，默认为`False`。

可能聪明的读者已经注意到，示例中每次切换路径，都创建了一个新的视图。那是因为，如果不是每次都清空`views`属性的话，在`views`属性中添加相同的对象会导致循环引用的问题。

当然，如果改成先创建好视图，每次都清空后重复使用也是可以的：

```python3
import flet as ft

def main(page: ft.Page):
    # 视图字典
    views = {
        '/':ft.View(
        	'/',
            [
                ft.AppBar(title=ft.Text('Home')),
                ft.Button(
                    'Go Page1',
                    on_click=lambda e:page.go('/page1')
                ),
            ]
        ),
        '/page1':ft.View(
        	'/',
            [
                ft.AppBar(title=ft.Text('Page1')),
                ft.Button(
                    'Go Home',
                    on_click=lambda e:page.go('/')
                ),
            ]
        ),
    }
    def route_change(route:ft.RouteChangeEvent):
        view = views.get(route.route)
        if view:
            route.page.views.clear()
            route.page.views.append(
                view
            )
        route.page.update()

    page.on_route_change = route_change
    page.go('/')

ft.app(target=main)
```

也可以使用模板，批量生成视图：

```python3
import flet as ft

def main(page: ft.Page):
    # 视图内容
    view_names = [('/','Home','Page1','/page1'),('/page1','Page1','Home','/')]
    # 基于视图内容，使用模板生成字典
    views = {
        name[0]:ft.View(
        	name[0],
            [
                ft.AppBar(title=ft.Text(name[1])),
                ft.Button(
                    f'Go {name[2]}',
                    on_click=lambda e,name=name:page.go(name[3])
                ),
            ]
        ) for name in view_names
    }
    def route_change(route:ft.RouteChangeEvent):
        view = views.get(route.route)
        if view:
            route.page.views.clear()
            route.page.views.append(
                view
            )
        route.page.update()

    page.on_route_change = route_change
    page.go('/')

ft.app(target=main)
```

既然每次都创建新的视图，那清空`views`属性又有什么用呢？

如果不清空的话，`views`属性就会包含先前打开的视图，就好像历史记录一样，这时，就可以通过点击顶部导航栏控件（也就是代码中的`AppBar`）的返回按钮，回到之前的视图：

```python3
import flet as ft

def main(page: ft.Page):
    # 视图信息
    views = {
        '/page1':{
            'title':'Page1',
            'button':'Go Home',
            'target':'/',
        },
        '/':{
            'title':'Home',
            'button':'Go Page1',
            'target':'/page1',
        },

    }

    def route_change(route:ft.RouteChangeEvent):
        view = views.get(route.route)
        if view:
            #route.page.views.clear()
            route.page.views.append(
                ft.View(
        	        route.route,
                	[
                        ft.AppBar(title=ft.Text(view['title'])),
                        ft.Button(
                            view['button'],
                            on_click=lambda e:page.go(view['target'])
                        ),
            		]
        		)
            )
        route.page.update()

    page.on_route_change = route_change
    page.go('/')

ft.app(target=main)
```

![navi_3](flet.assets/navi_3.png)

但是，单单注释掉清空`views`属性的代码，返回按钮也只是显示出来，并不能完全正常工作。因为返回按钮只负责触发`view_pop`事件并让界面显示（前端）执行回到之前视图的操作，并不会处理`route`属性和`views`属性的数据（后端）。因此，需要在主页面的视图弹出响应函数`on_view_pop`中，处理一下这两个属性：

```python3
import flet as ft

def main(page: ft.Page):
    # 视图信息
    views = {
        '/page1':{
            'title':'Page1',
            'button':'Go Home',
            'target':'/',
        },
        '/':{
            'title':'Home',
            'button':'Go Page1',
            'target':'/page1',
        },

    }

    def route_change(route:ft.RouteChangeEvent):
        view = views.get(route.route)
        if view:
            #route.page.views.clear()
            if len(route.page.views) and route.route == route.page.views[-1].route:
                return
            route.page.views.append(
                ft.View(
        	        route.route,
                	[
                        ft.AppBar(title=ft.Text(view['title'])),
                        ft.Button(
                            view['button'],
                            on_click=lambda e:page.go(view['target'])
                        ),
            		]
        		)
            )
        route.page.update()

    page.on_route_change = route_change

    def view_pop(view:ft.ViewPopEvent):
        view.page.views.pop()
        top_view = page.views[-1]
        view.page.route = top_view.route
        view.page.update()

    page.on_view_pop = view_pop
    page.views.clear()
    page.go('/')

ft.app(target=main)
```

除了处理那两个属性，代码中还清除了默认视图，这样当显示的视图为最后一个视图时，顶部导航栏将不显示返回按钮：

![navi_4](flet.assets/navi_4.gif)

注意，上面对顶部导航栏的处理仅作参考，因为Flet框架本身还在开发中，有很多未知问题和不足，在处理特别复杂的程序结构（比如示例中的循环链接视图）时有点力不从心，也容易出问题。如果读者在使用视图时存在问题或者不符合预期的情况，可以到Flet框架的官方社区寻求帮助。

看起来很像路径的路由参数或属性其实就是在浏览器中地址栏显示的路径，只不过需要将运行方式改为网页而不是客户端：

```python3
import flet as ft

def main(page: ft.Page):
    # 视图字典
    views = {
        '/':ft.View(
        	'/',
            [
                ft.AppBar(title=ft.Text('Home')),
                ft.Button(
                    'Go Page1',
                    on_click=lambda e:page.go('/page1')
                ),
            ]
        ),
        '/page1':ft.View(
        	'/',
            [
                ft.AppBar(title=ft.Text('Page1')),
                ft.Button(
                    'Go Home',
                    on_click=lambda e:page.go('/')
                ),
            ]
        ),
    }
    def route_change(route:ft.RouteChangeEvent):
        view = views.get(route.route)
        if view:
            route.page.views.clear()
            route.page.views.append(
                view
            )
        route.page.update()

    page.on_route_change = route_change
    page.go('/')

ft.app(target=main, view=ft.AppView.WEB_BROWSER)
```

更改之后，再运行程序的话，就会自动弹出浏览器，在浏览器中显示程序：

![navi_5](flet.assets/navi_5.png)

可以看到，地址栏中显示的地址后半部分正是设置的路由参数。默认情况下，可以输出此地址直接访问指定页面。除了这种直接和网站一样的地址，还可以配置`flet.app`的参数`route_url_strategy`为`'hash'`（默认为`'path'`)，在路由参数值前面添加`'#'`：

![navi_6](flet.assets/navi_6.png)

这就是Flet框架偏Web的功能。可能有的读者喜欢将Flet做成Web网站，这里就顺便说一下和路由相关的Web功能——路由模板。

路由模板由`flet.TemplateRoute`提供，该类接收一个路由值作为参数，返回一个可以重复匹配的路由模板对象，调用对象的`match`方法来匹配ExpressJS风格（英文冒号后接着合法变量名，表示地址中与该部分匹配的会被当做变量处理）的路由模板。如果与模板匹配，模板对象就会产生变量名对应的属性：

```python3
import flet as ft

def main(page: ft.Page):
    page.add(
        text := ft.Text(f'current id is {None}')
    )
    def route_change(route):
        troute = ft.TemplateRoute(page.route)
        if troute.match('/a:id'):
            text.value = f'current id is {troute.id}'
            text.update()
        else:
            text.value = f'current id is {None}'
            text.update()
    page.on_route_change = route_change

ft.app(target=main, view=ft.AppView.WEB_BROWSER,route_url_strategy='hash')
```

![navi_7](flet.assets/navi_7.png)

路由模板中的变量名支持后缀和更多正则表达式，具体可以参考 https://github.com/nickcoutsos/python-repath?tab=readme-ov-file#parameters ，但需要注意，Flet不支持所有的语法。

在变量名后使用不同的后缀表示不同的含义：

- `'?'`，表示该变量名可以匹配到空值，此时值为`None`，而不是返回匹配失败（`match`方法返回`False`表示匹配失败）。

- `'*'`，表示该变量名可以匹配空值或者多个符合要求的值。注意，此时英文冒号前的那个字符也会被当作可以匹配的字符。默认不匹配`'/'`，如果遇到`'/'`后面还有内容的，则匹配失败。但是英文冒号前为`'/'`的话，比如`'/:id*'`，就会把`'/'`和后面的内容一起匹配：

  ```python3
  import flet as ft
  
  def main(page: ft.Page):
      page.add(
          text := ft.Text(f'current id is {None}')
      )
      def route_change(route):
          troute = ft.TemplateRoute(page.route)
          if troute.match('/:id*'):
              text.value = f'current id is {troute.id}'
              text.update()
          else:
              text.value = f'current id is {None}'
              text.update()
      page.on_route_change = route_change
  
  ft.app(target=main, view=ft.AppView.WEB_BROWSER,route_url_strategy='hash')
  ```

  ![navi_8](flet.assets/navi_8.png)

- `'+'`，表示该变量名可以匹配一个或者多个符合要求的值（等于`'*'`后缀但遇到空值就匹配失败）。注意，此时英文冒号前的那个字符也会被当作可以匹配的字符。默认不匹配`'/'`，如果遇到`'/'`后面还有内容的，则匹配失败。但是英文冒号前为`'/'`的话，比如`'/:id*'`，就会把`'/'`和后面的内容一起匹配：

  ```python3
  import flet as ft
  
  def main(page: ft.Page):
      page.add(
          text := ft.Text(f'current id is {None}')
      )
      def route_change(route):
          troute = ft.TemplateRoute(page.route)
          if troute.match('/:id+'):
              text.value = f'current id is {troute.id}'
              text.update()
          else:
              text.value = f'current id is {None}'
              text.update()
      page.on_route_change = route_change
  
  ft.app(target=main, view=ft.AppView.WEB_BROWSER,route_url_strategy='hash')
  ```

  ![navi_8](flet.assets/navi_8.png)

- `({转义的正则表达式})`，表示除了路由模板其他部分的内容一致之外，变量匹配的内容还要与正则表达式再次匹配，常用于限定匹配内容的格式。比如，要求匹配的内容只能是`'a'`后面的数字且不能为空：

  ```python3
  import flet as ft
  
  def main(page: ft.Page):
      page.add(
          text := ft.Text(f'current id is {None}')
      )
      def route_change(route):
          troute = ft.TemplateRoute(page.route)
          if troute.match('/a:id(\\d+)'):
              text.value = f'current id is {troute.id}'
              text.update()
          else:
              text.value = f'current id is {None}'
              text.update()
      page.on_route_change = route_change
  
  ft.app(target=main, view=ft.AppView.WEB_BROWSER,route_url_strategy='hash')
  ```

  ![navi_7](flet.assets/navi_7.png)

### 4.3 快捷键

本节主要内容参考自 https://flet.dev/docs/cookbook/keyboard-shortcuts 。

定义主页面的键盘响应函数，就可以让Flet程序在表格控件、输入框控件没有捕获焦点时，响应键盘的操作。

需要注意的是，需要在添加控件前绑定键盘响应函数，否则函数无法正常响应。

示例如下：

```python3
import flet as ft

def main(page: ft.Page):
    def keyboard_handler(e:ft.KeyboardEvent):
        text.value = f'current key is {e.key}.'
        text.update()
    page.on_keyboard_event = keyboard_handler
    page.add(
        text := ft.Text(f'current key is None.')
    )

ft.app(target=main)
```

![keyboard_1](flet.assets/keyboard_1.png)

键盘响应函数接收一个`KeyboardEvent`类型的参数，该参数有以下属性：

- `key`属性，字符串类型，表示按键名（不包括右键菜单键、`ctrl`键、`alt`键、`shift`键、`meta`键）。比如`'S'`、`'F5'`。
- `shift`属性，布尔类型，表示`shift`键是否按下。
- `ctrl`属性，布尔类型，表示`ctrl`键是否按下。
- `alt`属性，布尔类型，表示`alt`键（在Mac系统中是`opt`键）是否按下。
- `meta`属性，布尔类型，表示`cmd`键（仅限Mac系统，Windows系统支持）是否按下。

### 4.4 引用控件

本节主要内容参考自 https://flet.dev/docs/cookbook/control-refs/ 。

在Flet中，有一种类似React的引用控件的用法，可以实现先定义控件的变量名和相关的交互逻辑，再通过添加控件的方式设计布局：

```python3
import flet as ft

def main(page: ft.Page):
    button = ft.Ref[ft.Button]()
    text = ft.Ref[ft.Text]()
    def handle_click(
        e:ft.OptionalControlEventCallable
    ):
        text.current.value = 'Hello'
        text.current.update()

    page.add(
        ft.Text(
            ref=text,
            value='None'
        ),
        ft.Button(
            ref=button,
            text='click',
            on_click=handle_click
        )
    )

ft.app(target=main)
```

![ref_1](flet.assets/ref_1.gif)

使用`flet.Ref`类实例化引用对象并分配给变量，然后在添加控件时，将控件的`ref`参数（所有控件均支持该参数）设置为先前的变量，这样就不需要使用海象表达式分配控件的变量了。

海象表达式在旧版本Python中不支持，且滥用的话会导致可读性变差。使用引用之后，控件对应的变量都会集中到前面，相当于把需要修改、暴露、添加交互逻辑的控件先写出来，方便后期维护。

示例中，实例化引用类时，使用了泛型，也就是中括号中写了这个引用类实际上对应哪种控件。这个不是必须的，但写了的话，开发环境会有对应的语法，后面使用引用对象时不需要盲写引用对象的方法和属性。

引用对象的`current`属性表示该引用对象的实际控件，在编写实际控件的交互逻辑时，该属性代指后面要分配的控件。、

需要注意的是，引用的用法不同于先创建控件的经典用法，引用对象相当于提前做了类型提示的模板，在后面创建对象、分配给`ref`参数前，引用对象的`current`属性不是实际的控件。因此，不能立即设置`current`属性的控件属性，只能在函数内执行这样的操作。因为函数在定义时不执行也不会检查变量的有效性，只会在调用时执行并检查变量，此时引用对象的`current`属性是已经创建的控件，自然没有问题。

### 4.5 超大列表（更新中）

本节主要内容参考自 https://flet.dev/docs/cookbook/large-lists 。





设置程序的图标：

```python3
import flet as ft
from pathlib import Path

def main(page: ft.Page):
    page.window.icon = Path(__file__).parent/'logo.ico'
    page.update()

ft.app(target=main)
```

